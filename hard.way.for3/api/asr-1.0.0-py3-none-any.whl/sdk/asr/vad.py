# -*- coding: utf-8 -*-
import http.client
import json
import traceback


class VadClient(object):
    def __init__(self, ip: str, port: int, arg: str):
        self.ip = ip
        self.port = port
        self.arg = arg

    def vad_request(self,
                    appkey: str,
                    token: str,
                    file_link: str,
                    callback_url: str,
                    open_ws: bool,
                    task_id=None,
                    enable_semantic_sentence_detection: bool = False,
                    enable_inverse_text_normalization: bool = False,
                    enable_hot_rule: bool = False,
                    enable_cn_rule: bool = False,
                    enable_db_rule: bool = False,
                    enable_speed_rule: bool = False,
                    enable_default_noise_pass=None,
                    enable_default_noise_command=None,
                    enable_default_noise_preemphasis=None,
                    enable_default_noise_equalizer=None,
                    enable_default_noise_speed=None,
                    enable_right_noise_pass=None,
                    enable_right_noise_command=None,
                    enable_right_noise_preemphasis=None,
                    enable_right_noise_equalizer=None,
                    enable_right_noise_speed=None
                ):
        """
                    appkey: str,
                    token: 密钥,
                    file_link: https文件路径,
                    callback_url: 回调地址,
                    open_ws: 实时 true/离线模式 false,
                    task_id= 任务编号，不传输服务器随机生成,
                    enable_semantic_sentence_detection: 符号,
                    enable_inverse_text_normalization: 中文转阿拉伯数字,
                    enable_hot_rule: 热词转换,
                    enable_cn_rule: 热词转换前后对比,
                    enable_db_rule: 分贝,
                    enable_speed_rule: 语速,
                    以下不确定可以不设置，服务器会采用默认最优策略：
                    enable_default_noise_pass 单/左声道 滤波器,
                    enable_default_noise_command      动态压缩,
                    enable_default_noise_preemphasis  预加重,
                    enable_default_noise_equalizer    均衡,
                    enable_default_noise_speed        加速,
                    enable_right_noise_pass  右声道，同上,
                    enable_right_noise_command=None,
                    enable_right_noise_preemphasis=None,
                    enable_right_noise_equalizer=None,
                    enable_right_noise_speed=None
        """
        # 构建请求体
        payload = json.dumps({
            "appkey": appkey,
            "token": token,
            "file_link": file_link,
            "callback_url": callback_url,
            "open_ws": open_ws,
            "task_id": task_id,
            "enable_semantic_sentence_detection": enable_semantic_sentence_detection,
            "enable_inverse_text_normalization": enable_inverse_text_normalization,
            "enable_hot_rule": enable_hot_rule,
            "enable_cn_rule": enable_cn_rule,
            "enable_db_rule": enable_db_rule,
            "enable_speed_rule": enable_speed_rule,
            "enable_callback": True,
            "max_single_segment_time": 500,
            "noise_type": 3,
            "enable_kafka_rule": False,
            # 音频处理
            "enable_default_noise_pass": enable_default_noise_pass,
            "enable_default_noise_command": enable_default_noise_command,
            "enable_default_noise_preemphasis": enable_default_noise_preemphasis,
            "enable_default_noise_equalizer": enable_default_noise_equalizer,
            "enable_default_noise_speed": enable_default_noise_speed,
            "enable_right_noise_pass": enable_right_noise_pass,
            "enable_right_noise_command": enable_right_noise_command,
            "enable_right_noise_preemphasis": enable_right_noise_preemphasis,
            "enable_right_noise_equalizer": enable_right_noise_equalizer,
            "enable_right_noise_speed": enable_right_noise_speed
        })

        # 构建请求头
        headers = {
            'Content-Type': 'application/json'
        }

        # 发送请求
        # 发送请求
        try:
            conn = http.client.HTTPConnection(self.ip, self.port)
            conn.request("POST", self.arg, payload, headers)
            res = conn.getresponse()
            data = res.read()
            print(data.decode("utf-8"))
        except Exception as e:
            print(f"请求异常：{str(e)}\n{traceback.format_exc()}")
        finally:
            conn.close()
